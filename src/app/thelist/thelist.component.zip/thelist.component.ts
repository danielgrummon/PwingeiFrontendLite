import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thelist',
  templateUrl: './thelist.component.html',
  styleUrls: ['./thelist.component.css']
})
export class ThelistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
